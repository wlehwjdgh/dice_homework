#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;
int d[1000][2];
int a[1000];

int main(){
    int n,i,j,temp;

    scanf("%d",&n);
/* 
    vector<int> a(n);
    vector<int> d(n);
*/
    for(i=0;i<n;i++){
        scanf("%d",a[i]);
    }

    for(i=0;i<n;i++){
        d[i][0] = 1;
        for(j=0;j<i;j++){
            if(a[i]>a[j] && d[j][0] + 1 > d[i][0] ){
                d[i][0] = d[j][0]+1;
            }
        }
    }

    for(i=n;i>0;i--){
        d[i][1] = 1;
        for(j=n;j>0;j--){
            if(a[i]>a[j] && d[j][1] + 1 > d[i][1] ){
                d[i][1] = d[j][1]+1;
            }
        }
        d[i][0] += d[i][1] -1;
    }
    temp = 0;
    for(i=0;i<n;i++){
        if(d[i][0]> temp) temp = d[i][0];
    }
    printf("%d\n", temp);
}