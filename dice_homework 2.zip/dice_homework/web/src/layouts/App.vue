<template>
  <div id="app">
    <div class="bgimg w3-display-container w3-animate-opacity w3-text-white">
      <slot>

      </slot>
    </div>
  </div>
</template>

<script>

export default {
  name: "app",
  data() {
    return {};
  },
  components: {
    
  },
  methods: {}
};
</script>

<style>
body,
h1 {
  font-family: "Raleway", sans-serif;
}
body,
html {
  height: 100%;
}
.bgimg {
  /*background-image: url("/static/images/korea_flag.png");*/
  min-height: 100%;
  height: 1005px;
  max-width: 100%;
  /* height: auto; */
  background-position: center;
  background-size: cover;
} 
</style>
