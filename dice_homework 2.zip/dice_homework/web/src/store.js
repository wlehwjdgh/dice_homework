import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

export const store = new Vuex.Store({
  state: {
    // walletId: "TEST",
    walletPw: "!dlrjdkslwlfhdapfhdggg",
    // wallet: "WALLET",
    keystore: null
  },
  mutations: {
    // updateWallet(state, payload) {
    //   state.wallet = payload;
    // },
    initialiseStore(state) {
      if (localStorage.getItem("store")) {
        this.replaceState(
          Object.assign(state, JSON.parse(localStorage.getItem("store")))
        );
      }
    }
  }
});

store.subscribe((mutation, state) => {
  localStorage.setItem("store", JSON.stringify(state));
});