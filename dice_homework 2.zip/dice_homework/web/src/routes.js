import Home from './pages/Home';

export default {
  '/': Home,
}