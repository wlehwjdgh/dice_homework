<template>
  <App>
    <div class="w3-display-topmiddle">
      <input 
        class="w3-button w3-ripple w3-orange"
        type="button"
        value= "주사위 굴리기"
        @click="getMine"
        id="getNumber"
      >
    </div>
    <div class="w3-display-middle">
      <div class="w3-center">
        <div class="flagname">
          <p @click="getMine" v-if="number >= 0">{{nationStr}}</p>
        </div>
        <img @click="getMine" class="flagimg" v-bind:src = nationPic /> 
      </div>
    </div>
  </App>
</template>

<script>
import App from "../layouts/App";
import IconService from "icon-sdk-js";

const httpProvider = new IconService.HttpProvider(
  "https://bicon.net.solidwallet.io/api/v3"
);
//const httpProvider = new IconService.HttpProvider("https://ctz.solidwallet.io/api/v3");
const iconService = new IconService(httpProvider);

const flagList = [
    "1",
    "2",
    "3",
    "4",
    "5",
    "6"
];

const picList = [
    "/static/images/0.png",
    "/static/images/1.png",
    "/static/images/2.png",
    "/static/images/3.png",
    "/static/images/4.png",
    "/static/images/5.png"
];

export default {
  name: "home",
  data() {
    return {
      number: 0,
      nationStr:"1",
      nationPic:"/static/images/0.png",
    };
  },
  components: {
    App
  },
  methods: {
    make() {
      this.getMine();
    
    },
    getMine() {
      console.log("this.getMine()")
      const tx = new IconService.IconBuilder.CallBuilder()
        .to("cx2dc8558e18c4dbac92e87984ec051a496da34c50")
        .method("get_num")
        .build();
      iconService
        .call(tx)
        .execute()
        .then(result => {
          this.number = parseInt(((Number(result) * Number(Math.random())) %5))
          this.nationStr = flagList[this.number];
          this.nationPic = picList[this.number];
        console.log(this.number);
        });
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
.w3-button {
  margin : 50px;
}
.flagimg {
    border: 15px solid black;
  /*background-image: url("/static/images/0.png");*/
  
  height: 300px;
  width: 400px;
  /* height: auto; */
  background-position: center;
  background-size: cover;
} 

.flagname {
  color: black
}
</style>