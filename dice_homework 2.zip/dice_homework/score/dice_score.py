from iconservice import *

TAG = 'DiceGameScore'

class DiceGameScore(IconScoreBase):
    _D_NUM = "d_num"

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._d_num = DictDB(self._D_NUM,db,int)

    def on_install(self) -> None:
        super().on_install()

    def on_update(self) -> None:
        super().on_update()

    @external(readonly=True)
    def get_num(self) -> str:
        return 1233456
